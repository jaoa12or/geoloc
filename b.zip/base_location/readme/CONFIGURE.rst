#. Go to *Contacts / Configuration / Localization / Cities*.
#. Create a new City.

#. Go to *Contacts / Configuration / Localization / Zips*.
#. Create a new Zip and relate it to the city (you can also create the Zip from the City).

or, with module 'Contacts Directory' installed:
#. Go to *Contacts / Configuration / Localization / Countries*.
#. Locate the desired country.
#. Press on the button 'Cities' / 'Zips'.
