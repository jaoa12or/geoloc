#. Access a partner record
#. Fill the field *Location completion*
#. Information about country, state, city and zip will be filled automatically
