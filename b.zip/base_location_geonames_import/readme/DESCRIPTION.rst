This module adds a wizard to import cities and/or city zip entries from
`Geonames <http://www.geonames.org/>`_ database.
